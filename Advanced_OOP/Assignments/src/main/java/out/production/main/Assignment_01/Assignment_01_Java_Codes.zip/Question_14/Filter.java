package Assignment_01.Question_14;

public interface Filter {
    boolean accept(String x);
}
