package Assignment_02.Question_01;

public interface Sampler {
    double getValue();
}
