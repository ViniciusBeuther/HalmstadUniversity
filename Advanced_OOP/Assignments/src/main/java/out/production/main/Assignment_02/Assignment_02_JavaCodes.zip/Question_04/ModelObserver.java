package Assignment_02.Question_04;

// Interface for Observer
public interface ModelObserver {
    void modelChanged();
}
