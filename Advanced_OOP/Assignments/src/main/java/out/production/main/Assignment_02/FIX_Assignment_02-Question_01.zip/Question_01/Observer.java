package Assignment_02.Question_01;

public interface Observer {
    public void update(double x);
}
